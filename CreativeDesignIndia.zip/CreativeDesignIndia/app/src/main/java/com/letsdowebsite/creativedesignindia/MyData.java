package com.letsdowebsite.creativedesignindia;

/**
 * Created by Dell on 5/16/2018.
 */

public class MyData {
   static String[] nameArray = {"" };

    static Integer[] drawableArray = {R.drawable.offerr };

    static String[] nameArrey = {"New Arrivals", "Mens", "Womens", "Kids"};

    static Integer[] drawableArrey = {R.drawable.ne, R.drawable.man, R.drawable.wo, R.drawable.ki};

    static String[] name = {""   };

    static Integer[] drawable= {R.drawable.cdi };

    static String[] Arrey = {"", ""};

    static Integer[] draw = {R.drawable.become, R.drawable.buymember};

}