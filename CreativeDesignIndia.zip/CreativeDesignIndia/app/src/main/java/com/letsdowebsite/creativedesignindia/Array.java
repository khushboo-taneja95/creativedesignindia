package com.letsdowebsite.creativedesignindia;

/**
 * Created by Dell on 5/16/2018.
 */
public class Array {
    String name;
    int image;

    public Array(String name, int image) {
        this.name = name;
        this.image=image;
    }
    public String getName() {
        return name;
    }
    public int getImage() {
        return image;
    }}
