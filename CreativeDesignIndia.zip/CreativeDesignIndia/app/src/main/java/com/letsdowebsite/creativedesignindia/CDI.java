package com.letsdowebsite.creativedesignindia;

import android.content.Intent;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;


public class CDI extends AppCompatActivity {

    private WebView mWebview;
    ImageView lo, back;
    SwipeRefreshLayout swipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.cdi );
        swipe = (SwipeRefreshLayout) findViewById( R.id.swipe );
        swipe.setOnRefreshListener( new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                WebAction();
            }
        } );

        WebAction();
    }
    public void WebAction() {

        mWebview = (WebView) findViewById( R.id.webview );
        mWebview.getSettings().setJavaScriptEnabled( true );
        mWebview.getSettings().setAppCacheEnabled( true );
        mWebview.loadUrl( "https://cdifootwear.com/" );
        swipe.setRefreshing( true );
        mWebview.setWebViewClient( new WebViewClient() {

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {

                mWebview.loadUrl( "file:///android_asset/error.html" );

            }

            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }


            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return super.shouldOverrideUrlLoading(view, url);
            }



            public void onPageFinished(WebView view, String url) {
                // do your stuff here
                swipe.setRefreshing( false );

                mWebview.loadUrl("javascript:(function() { " +
                        "var top = document.getElementsByClassName('top-logo-grid')[0].style.display='none'; " +
                        "})()");


                mWebview.loadUrl("javascript:(function() { " +
                        "var search = document.getElementsByClassName('search-block-grid')[0].style.display='none'; " +
                        "})()");



                mWebview.loadUrl("javascript:(function() { " +
                        "var icons = document.getElementsByClassName('support-icons')[0].style.display='none'; " +
                        "})()");


                mWebview.loadUrl("javascript:(function() { " +
                        "var footer = document.getElementsByClassName('tygh-footer')[0].style.display='none'; " +
                        "})()");

            }
        });


        lo = (ImageView) findViewById( R.id.lo );
        lo.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendIntent = new Intent();
                sendIntent.setAction( Intent.ACTION_SEND );
                sendIntent.putExtra( Intent.EXTRA_TEXT,
                        "Hey check out my app at: https://play.google.com/store/apps/details?id=com.google.android.apps.plus" );
                sendIntent.setType( "text/plain" );
                startActivity( sendIntent );
            }
        } );


        back = (ImageView) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mWebview.canGoBack()) {
                    mWebview.goBack();
                } else {
                    Intent intent = new Intent(CDI.this, INDIA.class);
                    startActivity(intent);
                }
            }
        });
    }
    public void onBackPressed () {
        if (mWebview.canGoBack()) {
            mWebview.goBack();
        } else {
            // Let the system handle the back button
            super.onBackPressed();
        }
    }

}

