package com.letsdowebsite.creativedesignindia;

/**
 * Created by Dell on 5/16/2018.
 */

public class MyDataNavi   {
    static String[] nameArray = {"" };

    static Integer[] drawableArray = {R.drawable.bstt };

    static String[] nameArrey = {"Free Design","New Arrivals", "Mens", "Womens", "Kids"};

    static Integer[] drawableArrey = {R.drawable.design, R.drawable.ne, R.drawable.man, R.drawable.wo, R.drawable.ki};

    static String[] name = {""   };

    static Integer[] drawable= {R.drawable.cdinavi };


    static String[] Arrey = {"", ""};

    static Integer[] draw = {R.drawable.supp, R.drawable.raww};

}